
class Employee:
  emp_count = 0
  def __init__(self, name, family, salary, department):

        self.name = name
        self.family = family
        self.salary = salary
        self.department = department
        Employee.emp_count = Employee.emp_count + 1

  def avg_sal(self, emps):
      sum_sal = 0
      for i in emps:
            sum_sal= sum_sal+ i.salary


      print(sum_sal/len(emps))


class Fulltime_Employee(Employee):

      def __init__(self, name, family, salary, department):
         Employee.__init__(self, name, family, salary, department)

list = []
list.append(Employee('Jamielannister', 'Joffrey', 40000, 'Finance'))
list.append(Employee('Branstark', 'Emiliaclarke', 55000, 'Marketing'))

list.append(Fulltime_Employee('Johnsnow', 'Arrya', 63000, 'Business'))
list.append(Fulltime_Employee('Sophie', 'Robb', 30000, 'Administrative'))

list[0].avg_sal(list)
list[2].avg_sal(list)


print(Employee.emp_count)

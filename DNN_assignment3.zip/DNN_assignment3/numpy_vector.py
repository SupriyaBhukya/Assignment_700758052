

import numpy as np

vec = np.random.uniform(1, 20, 20)

mat = vec.reshape(4, 5)

mat[np.arange(4), mat.argmax(axis=1)] = 0

print(mat)
